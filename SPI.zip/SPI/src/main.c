#include "em_chip.h"
#include "em_cmu.h"

int main(void)
{
  /* Chip errata */
  CHIP_Init();
  /* Enable clock HFRCO */
  CMU_HFRCOBandSet(cmuHFRCOFreq_26M0Hz);

  /* Infinite loop */
  while (1) {
  }
}
