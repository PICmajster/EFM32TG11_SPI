/*
 * delay.h
 *
 *  Created on: 24 paź 2018
 *      Author: wat
 */

#ifndef SRC_DELAY_H_
#define SRC_DELAY_H_

void delayMs(uint16_t milliseconds);

#endif /* SRC_DELAY_H_ */
